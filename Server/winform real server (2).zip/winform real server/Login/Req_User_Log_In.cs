﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace winform_real_server
{
    class Req_User_Log_In
    {
        public static string result;
        public static string level;
        public static string right;
        public static string nak_reason;
    }
}
