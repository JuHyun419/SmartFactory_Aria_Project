﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace winform_real_server.PI
{
    class Pi
    {
        public string Pi_lot_id { get; set; }
        public string Pi_model_name { get; set; }
        public string Pi_prod_count { get; set; }
        public string Pi_model_temp { get; set; }
        public string Pi_model_humid { get; set; }
        public string Pi_line { get; set; }
        public string Pi_prod_color { get; set; }
    }
}
