import serial 
from time import *
from multiprocessing import Queue, Process
from import_detect import *
import Adafruit_DHT

BAUDRATE = 9600
time_flag = 0
last_time = 0

sensor = Adafruit_DHT.DHT11
pin = '4'

def humanity_temp():
    
    humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)

    if humidity is not None and temperature is not None:
        return int(temperature), int(humidity)
    else:
        #print('Failed to get reading. Try again!')
        temperature = 0 
        humidity = 0 
        return temperature, humidity   
    
def serial_open():
    ser = serial.Serial('/dev/ttyAMA0', baudrate = BAUDRATE)
    
    return ser

def command_arduino(ser, i):
    command = ["go\n", "stop\n", "rgrab\n", "fgrab\n"]
    
    command[i] = command[i].encode('utf-8')
    ser.write(command[i])

def receive_arduino(ser, q):
    if ser.readable():
        data = ser.readline()
        data = str(data[:-1].decode())
        q.put(data)

def get_H_T():
    
    global time_flag
    global last_time
    
    if time_flag == 0:
        last_time = time()
        time_flag = 1
    
    if time() - last_time >= 10:
        temp, hum = humanity_temp()
        time_flag = 0
        print('Temp={0}*C  Humidity={1}%'.format(temp, hum))
   
def image_process(cap, ser, q, state_flag, state_list):

    goods_x, signal, barcode = cam(cap)
        
    if signal == 'P' and (goods_x >= 60 and goods_x <= 272):
        if state_flag == "SEND_STOP":
            command_arduino(ser, 1)
            state_flag = "SEND_GRAB"

        if state_flag == "SEND_GRAB"  and len(barcode) > 5:
            sleep(0.01)
            command_arduino(ser, 2)
            state_flag = "WAIT"
            
    elif signal == 'F' and (goods_x >= 60 and goods_x <= 272):
        if state_flag == "SEND_STOP":
            command_arduino(ser, 1)
            state_flag = "SEND_GRAB"

        if state_flag == "SEND_GRAB"  and len(barcode) > 5:
            sleep(0.01)
            command_arduino(ser, 3)
            state_flag = "WAIT"
            
    else:
        if q.empty() == False and signal == 'N':
            rx_data = q.get()
            print(rx_data)
            if rx_data == "complete":
                command_arduino(ser, 0)
                state_flag = "SEND_STOP"
    return state_flag
    
def main_process(ser, q):
    
    state_list = ["WAIT", "SEND_STOP", "SEND_GRAB" ]

    cap = open_cam()
    command_arduino(ser, 0)
    state_flag = state_list[1]
    q.put("start")
    
    sleep(1)
    
    while True:
        
        state_flag = image_process(cap, ser, q, state_flag, state_list)
        
        if cv.waitKey(1) & 0xFF == 27:
            break 
          
    cap.release()
    cv.destroyAllWindows()  

def serve_process(ser, q):
    while True:
        receive_arduino(ser, q)
        
def temp_huminity_process(q):
    factory_state = ""
    temp_state = 1
    
    while True:
        if q.empty() == False and temp_state == 1:
            factory_state = q.get()
            temp_state = 2
        
        if factory_state == "start" and temp_state == 2:
            get_H_T()
try:
    if __name__ == "__main__":
        print("start \n")
        q = Queue()
        ser = serial_open()
        p1 = Process(target = main_process, args = (ser,q))
        p2 = Process(target = serve_process, args = (ser,q))
        p3 = Process(target = temp_huminity_process, args = (q, ))
        p1.start()
        p2.start()
        p3.start()
        
except KeyboardInterrupt:
    print("exit() \n")
    p1.join()
    p2.join()
    p3.join()