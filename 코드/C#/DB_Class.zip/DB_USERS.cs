﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_Class
{
    class DB_USERS
    {
        public string User_Id { set; get; }
        public string Pass_Word { set; get; }
        public string Level { set; get; }
        public string E_Mail { set; get; }
        public string First_Name{ set; get; }
        public string Last_Name { set; get; }
    }
}
